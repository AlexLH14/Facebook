const proxy_host = "proxyadcuality.arcemedia.es"; // Reemplaza con el host de tu proxy
const proxy_port = "2290"; // Reemplaza con el puerto de tu proxy
const proxy_user = "adcuality"; // Reemplaza con tu usuario del proxy
const proxy_pass = "adcuality321"; // Reemplaza con tu contraseña del proxy

const config = {
  mode: "fixed_servers",
  rules: {
    singleProxy: {
      scheme: "http",
      host: proxy_host,
      port: parseInt(proxy_port)
    },
    bypassList: ["localhost"]
  }
};

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

function callbackFn(details) {
  return {
    authCredentials: {
      username: proxy_user,
      password: proxy_pass
    }
  };
}

chrome.webRequest.onAuthRequired.addListener(
  callbackFn,
  {urls: ["<all_urls>"]},
  ["blocking"]
);
